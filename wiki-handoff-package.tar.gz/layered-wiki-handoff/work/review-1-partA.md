# Micro-review Part A — bm25-results.md vs analysis-wiki-talk-01.md

| claim | repo line | source match file:line | PASS/FAIL |
|---|---|---|---|
| 37,402 بايت · 129 مقطعًا — أصغر 20 صفحة | repo/index/bm25-results.md:10 | /workspace/wiki/work/analysis-wiki-talk-01.md:163,228 | PASS |
| 601,084 بايت — إجمالي هيثم (210 صفحة) | repo/index/bm25-results.md:18 | /workspace/wiki/work/analysis-wiki-talk-01.md:233 | PASS |
| 123,205 بايت — أكبر 20 صفحة | repo/index/bm25-results.md:18 | /workspace/wiki/work/analysis-wiki-talk-01.md:233 | PASS |
| 14/15 في المرتبة الأولى، 15/15 في أول 3 — على أكبر 20 | repo/index/bm25-results.md:19 | /workspace/wiki/work/analysis-wiki-talk-01.md:234 | PASS |
| 12/15 في المرتبة الأولى، 14/15 في أول 3 — على كل 210 | repo/index/bm25-results.md:24 | /workspace/wiki/work/analysis-wiki-talk-01.md:235,454 | PASS |
| 429 ميجا — الرام المتاح 2026-11-03 09:07 | repo/index/bm25-results.md:38 | /workspace/wiki/work/analysis-wiki-talk-01.md:165,246 | PASS |

Verdict: All 6 claims PASS — numeric claims in bm25-results.md are directly supported by analysis-wiki-talk-01.md.
