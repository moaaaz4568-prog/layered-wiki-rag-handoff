# CHUNKING — سياسة التقطيع

> الحالة: REPORTED — من `../../work/analysis-wiki-talk-01.md` §1.8 القاعدة 12 + §3.1 + §4.3.
> وسم الدليل: OBSERVED = مقاس على القرص، REPORTED = منقول من تقرير، PROPOSED = مقترح مستقبلي، UNKNOWN = لا دليل، NOT_RUN = لم يُشغَّل بعد.

## 1. التعريف الحاكم

- **المقطع الصحيح:** عنوان/فقرة أو نطاق محارف أو جدول/قائمة | REPORTED — `../../work/analysis-wiki-talk-01.md` §1.8
- **المقطع الأعمى بالحروف مرفوض:** لا تقطيع متساوٍ دون فهم الحدود الدلالية | REPORTED — `../../work/analysis-wiki-talk-01.md` §3.1
- **كل إجابة باستشهاد للمقطع الخام:** المقطع هو وحدة الاستشهاد الصغرى | REPORTED — `../../work/analysis-wiki-talk-01.md` §1.11
- **تقطيع تدريجي (Incremental):** مادة جديدة = raw أولًا ثم wiki ثم إعادة فهرسة الجزء وحده | REPORTED — `../../work/analysis-wiki-talk-01.md` §1.11

## 2. السياسات التشغيلية (PROPOSED)

- **عنوان/فقرة:** كل قسم بعنوانه مقطعًا مستقلًا يحمل عنوانه ومساره الخام | PROPOSED — `../../work/analysis-wiki-talk-01.md` §4.3
- **نطاق محارف:** كاحتياط للنص المتواصل الطويل بلا عناوين واضحة | PROPOSED — `../../work/analysis-wiki-talk-01.md` §3.1
- **جدول/قائمة:** كل جدول أو قائمة مقطعًا واحدًا لا يُفكّك صفوفه | PROPOSED — `../../work/analysis-wiki-talk-01.md` §3.1
- **الحدود:** لا تقطيع عموديًا عبر عنوان رئيسي يجعل المعنى منتقًا | PROPOSED — `../../work/analysis-wiki-talk-01.md` §4.3
- **التداخل (Overlap):** UNKNOWN — لا قيمة معلنة في البريف، تُختبر بعد القياس | UNKNOWN — `../../work/analysis-wiki-talk-01.md` §3.1

## 3. الحالات غير المحسومة

- **النص بلا عناوين:** العناوين لا تعالج النص المتواصل بلا عناوين | UNKNOWN — `../../work/analysis-wiki-talk-01.md` §3.1
- **الجداول:** العناوين لا تعالج الجداول — وحدة تقطيع مقابل أخرى غير محسومة | UNKNOWN — `../../work/analysis-wiki-talk-01.md` §3.1
- **حد الرأي الغبي/المختلف:** يغيّر كمية ما يدخل التقطيع فعليًا | UNKNOWN — `../../work/analysis-wiki-talk-01.md` §3.1
- **تجربة التقطيع على 20 صفحة هيثم:** تم القياس؛ على 210 الكاملة تُبنى القياسات التالية | NOT_RUN — `../../work/analysis-wiki-talk-01.md` §6

## 4. قياسات شاهدة (OBSERVED)

- 6 ويكيات: 5,896 صفحة، 31.3MB | OBSERVED — `../../work/analysis-wiki-talk-01.md` §1.7
- هيثم 210 صفحة: 601,084 بايت | OBSERVED — `../../work/analysis-wiki-talk-01.md` §1.10
- أصغر 20 صفحة لهيثم: 37,402 بايت، 129 مقطعًا | OBSERVED — `../../work/analysis-wiki-talk-01.md` §1.7
- متوسط صفحة هيثم 2,336 بايت مقابل ابن تيمية 10,458 بايت | OBSERVED — `../../work/analysis-wiki-talk-01.md` §1.7
- BM25 على أكبر 20 هيثم: 14/15 في الأولى، 15/15 في أول 3 | OBSERVED — `../../work/analysis-wiki-talk-01.md` §1.10
- BM25 على كل 210: 12/15 في الأولى، 14/15 في أول 3 | OBSERVED — `../../work/analysis-wiki-talk-01.md` §1.10
- فجوة الصياغات العامة: الجلطة عند الولادة المرتبة 28، الدين الحق المرتبة 35 | OBSERVED — `../../work/analysis-wiki-talk-01.md` §1.10
- أرشيف الويكي: 212MB، 2,713 ملفًا على القرص | OBSERVED — `../../work/archive-inventory-01.md` §2

## 5. ارتباط التقطيع بالتقييم

- لا توسع على فشل: أصلح التقطيع/الوسوم/المضمّن أولًا قبل أي توسع | REPORTED — `../../work/analysis-wiki-talk-01.md` §1.8
- التقييم يُجرى على Recall@10 (مقترح k=10 — القيمة النهائية UNKNOWN، config/thresholds.yaml) + زمن + استشهاد على 20 سؤالًا معروفًا | PROPOSED — `../../work/repo-plan-01.md` §4.6
- الترتيب الجديد على الصفحات الغنية الطويلة تفوق على الصفحة الرفيعة التي فيها الإجابة | OBSERVED — `../../work/analysis-wiki-talk-01.md` §1.10
