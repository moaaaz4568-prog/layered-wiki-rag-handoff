# الروابط الخارجية — سياق وتاريخ (بلا أسرار)

> **قاعدة صارمة:** كل رابط هنا بسياق اختصار وتاريخه. روابط المفاتيح لا تُنسخ قيمتها؛ تُشار إليها بعبارة «مفتاح — القيمة لا تُنسخ». لا تُفهرس أي قيمة سرية.
> **المصدر:** `../../work/analysis-wiki-talk-01.md` §2.1 + `../../work/analysis-session-01.md` §2. الآن لا يُفتح عن للروابط خارج السياق إلا بإذن.

| الرابط | السياق | التاريخ | الدليل |
|---|---|---|---|
| `https://www.transfernow.net/dl/20261101suwmDHnJ` | ملف السياق الكامل المحدث لكلود (نسخة 9MB) — أول ظهور | 2026-11-01 في البريف الأصلي | REPORTED |
| `https://github.com/topoteretes/cognee` | GraphRAG المقترح — بُني عليه التصميم، لكنه ليس الاختيار النهائي (تأجيل) | 2026-10-30 18:48 | REPORTED |
| `https://github.com/starmynd-org/infinite-brain-os.git` | نظام تنظيم معرفة MIT (584 ملف، 4.7MB، 228 عقدة) — دراسته ودمج مفاهيمه | 2026-11-01 17:50 | REPORTED |
| `https://youtu.be/U7UQlAWCKo8?is=alX8CoRG8Jn9HiZx` | اختبار يوتيوب الثلاثي بدون كوكيز | 2026-10-19 17:27 | REPORTED |
| `https://youtu.be/aMOgezEHXUc?si=PSAigQYpvPf-13RI` | فيديو من الثلاثة | 2026-10-31 20:59 | REPORTED |
| `https://youtu.be/pvcSMlhNKlo?si=2G1bCkdvW27zFDdz` | فيديو من الثلاثة | 2026-10-31 20:59 | REPORTED |
| `https://youtu.be/DTCyvo6cC54?si=A3yb5R7-dm4-q844` | Nate Herk — المستويات | 2026-10-31 20:59 | REPORTED |
| `https://youtube.com/@dr.haitham_talaat?si=SJb66qJcY4o3oMeR` | قناة هيثم طلعت | 2026-10-19 19:16 | REPORTED |
| `https://api.yukino.my/keys` | مفتاح — القيمة لا تُنسخ | 2026-10-30 18:46 / 21:31 / 22:07 | OBSERVED/REPORTED |
| `https://api.hcnsec.cn` | مفتاح — القيمة لا تُنسخ (كان داخل JSON `_type: newapi_channel_conn`) | 2026-10-19 17:36 | OBSERVED/REPORTED |
| `https://nlozx-2a04-4e41-14-1e1--d091-1e1.run.pinggy-free.link` | رابط ترمنال pinggy الأول | 2026-10-19 19:16 | REPORTED |
| `https://pmbwb-2a04-4e41-10-efc--dd64-efc.free.pinggy.net` | رابط ترمنال جديد | 2026-10-27 08:52 | REPORTED |
| `http://127.0.0.1:4416/ping` | PoToken server المحلي في سكربت الكولاب | 2026-10-19 17:24 | REPORTED |
| GitHub `geasas/youtube-transcripts` + `transcripts/transcripts_final.zip` | مستودع رفع النصوص في سكربت الكولاب | 2026-10-19 17:24 | REPORTED |
| `github:goodnight000/api-anything` | أداة api-anything المحملة عبر `npx -y` | 2026-10-31 21:11 | REPORTED |

## روابط TransferNow من الجلسة 01 — السياق فقط (بلا أسرار)

| الرابط | السياق | التاريخ | الدليل |
|---|---|---|---|
| `https://www.transfernow.net/dl/20261103BdZVc6uf` | برومبت المستخدم — تنزيل `/workspace/wiki/pro.md` (1992 بايت) | س13013 / س14218 | REPORTED |
| `https://www.transfernow.net/dl/20261103UuphJtM8` | ملف كلام الويكي (`wiki_all_talk.md`) | س14218 | REPORTED |
| `https://www.transfernow.net/dl/202611035dwLrJSx` | البرومبت/الصوت — خارج النطاق ما عدا حدودًا | س14218 | REPORTED |
| `https://www.transfernow.net/dl/20261101suwmDHnJ` | ذُكر باسم رفع سابق، وانتهى بحالة `Transfer not found` بحسب تقرير الوكيل الفرعي | الجلسة 01 | REPORTED |
| `https://github.com/moaaaz4568-prog/layered-wiki-rag` | المستودع الخاص الناجح (commit `5b70e5923099bedcb3c911b9a20c3eb3821c8c64`) | س12935 | REPORTED |
| `https://github.com/moaaaz4568-prog/layered-wiki-rag/releases/tag/v1.0.0` | إصدار أعاد 404 — لا يمكن تأكيد أصوله؛ يُوثَّق كعنصر مفقود لا كنص بديل | س14323 | REPORTED |

## ملاحظة عن روابط المفاح

- `api.yukino.my/keys` و `api.hcnsec.cn` يُذكران هنا **كعبارة وصفية فقط** «مفتاح — القيمة لا تُنسخ». لا تُنسخ أي قيمة مفتاح أو توكن إلى المستودع، ولا تُستخدم إلا لحظياً عبر متغير بيئة عند توفر الإذن.
- جميع روابط TransferNow أعلاه روابط مشاركة مؤقتة؛ صلاحيتها تنتهي بعد مدة. فهرستها هنا للتوثيق فقط وليست نسخة احتياطية.
